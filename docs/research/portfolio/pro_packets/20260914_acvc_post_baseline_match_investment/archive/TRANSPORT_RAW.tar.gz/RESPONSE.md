File: RESPONSE.md

Commit: ade27ced0e8a0ab63b89b9396bd0a7668f1d9f2b

Comment: Issue #14 delivery