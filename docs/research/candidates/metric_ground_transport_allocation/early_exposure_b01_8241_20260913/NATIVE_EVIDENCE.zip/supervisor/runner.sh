#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/mgtap-early-8241-20260913/pid"
START_TS=$(date +%s)
echo "=== Task 'mgtap-early-8241-20260913' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/mgtap-early-8241-20260913/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/mgtap-early-8241-20260913/docs/research/candidates/metric_ground_transport_allocation/early_exposure_b01_8241_20260913/COMMAND.sh' >> "/home/wu/.agent-tasks/mgtap-early-8241-20260913/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/mgtap-early-8241-20260913/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/mgtap-early-8241-20260913/status"
else
    echo "failed" > "/home/wu/.agent-tasks/mgtap-early-8241-20260913/status"
fi
echo "=== Task 'mgtap-early-8241-20260913' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/mgtap-early-8241-20260913/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
