"""Read retained native bytes only: no model loading, RNG, environment or learner."""
import ast
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import zipfile

ROOT = Path(__file__).resolve().parents[5]
RAW = Path(__file__).resolve().parent
OUT = ROOT / "docs/research/candidates/metric_ground_transport_allocation/unequal_exposure_b01_8231_20260913"
OUT.mkdir(parents=True, exist_ok=True)
EXPECTED = {
    "summary.json": "1adb33e755d191becfe94c79eabec65c412c9f78c58feca7d75357d684a5d0a3",
    "resource_admission.json": "fdd5e1eddf3f9de809b9bdf0504818c8075511eaee1815ad392ed688fe31afd2",
    "native_time.txt": "bbf8552dce78b76140e59b81d40980cfec2fa3612832aa221f39865b6482b56a",
    "episodes.jsonl": "dc23eea0c2eb8ff5a026b97da5324079ac8b02fd9fedc8f6e411ce20846f6005",
    "final_DENSE.pt": "e05b8bd86c76dbf21b7843ee66f4dcca1427503420a4d3c8e104ed6f9253fd65",
    "rollouts.jsonl": "a259908d9aee806d8397b66c51551883f8f97b6d5a928fbd6b99b960fcd32d67",
    "final_COND.pt": "addcd6b5f3bea99e7948f15cad438e9af06e84f1c1753bce9ca18558922d216f",
}

def digest(path):
    return {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")

for name, expected in EXPECTED.items():
    assert digest(RAW / name)["sha256"] == expected, name
s = json.loads((RAW / "summary.json").read_text())
rows = [json.loads(line) for line in (RAW / "episodes.jsonl").read_text().splitlines()]
rollouts = [json.loads(line) for line in (RAW / "rollouts.jsonl").read_text().splitlines()]
assert rows == s["rows"]
assert s["launch_sha"] == "ecf40e0ade4576fd75ffb0eab09425cb5c4ce059"
assert s["source_sha"] == "a9fbfddcfd8e0e714f6fe33b15c3d971fa95fd85"
assert s["seed"] == 8231 and s["status"] == "COMPLETE"
assert s["pair_factory_calls"] == 1 and s["top_level_model_constructions"] == 6
assert not s["limits"] and not s["binding_errors"] and not s["cap_breach"]
assert len(rows) == 1344 and len(rollouts) == 640
base = 823100000
for arm, train in (("COND", 512), ("DENSE", 768)):
    info = s["arms"][arm]
    assert info["fit_complete"] and info["complete"]
    expected_counts = dict(train_episodes=train, eval_episodes=32,
                           train_team_steps=train*256, eval_team_steps=8192,
                           team_steps=(train+32)*256, rollouts=train//2,
                           optimizer_steps=train*2, diagnostic_frames=0, duration_decisions=0)
    assert all(info["counts"][k] == v for k, v in expected_counts.items())
    assert all(group["displacement"] > 0 for group in info["exposure"].values())
    for phase, count, reset, duration in (("train", train, 1000, 4000), ("eval", 32, 2000, 5000)):
        panel = [r for r in rows if r["arm"] == arm and r["phase"] == phase]
        assert [r["episode"] for r in panel] == list(range(count))
        for r in panel:
            e = r["episode"]
            assert r["pair_master"] == 8231 and r["steps"] == 256
            assert r["reset_seed"] == base+reset+e
            assert r["duration_seed"] == base+duration+e
            assert r["velocity_seed"] == base+(21 if phase == "train" else 3000+e)
            assert math.isfinite(r["J"]) and r["J"] == r["reward_sum"]/256
    updates = [r for r in rollouts if r["arm"] == arm]
    assert [r["rollout"] for r in updates] == list(range(train//2))
    for r in updates:
        assert r["pair_master"] == 8231 and r["episodes"] == 2 and r["steps"] == 512
        assert r["optimizer_steps"] == 4 and [e["epoch"] for e in r["epochs"]] == [0,1,2,3]
        assert all(math.isfinite(v) for e in r["epochs"] for v in e.values())
    with zipfile.ZipFile(RAW / f"final_{arm}.pt") as z:
        assert z.testzip() is None

for k, expected in {"team_steps":344064, "optimizer_steps":2560,
                    "train_episodes":1280, "eval_episodes":64, "rollouts":640,
                    "partial_episode_steps":0, "diagnostic_frames":0, "duration_decisions":0}.items():
    assert s["counts"][k] == expected
reducer_path = ROOT / "experiments/candidates/metric_ground_transport_allocation/mgtap_native_ground_geometry_b01/conditional_pooling.py"
tree = ast.parse(reducer_path.read_text())
pure = ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ("reading", "primary")], type_ignores=[])
ns = {"math":math, "statistics":statistics, "COND":"COND", "DENSE":"DENSE"}
exec(compile(pure, str(reducer_path), "exec"), ns)
p = ns["primary"](rows)
assert p == s["primary"]
delta = p["COND_minus_DENSE"]["differences"]
means = {arm:statistics.mean(scores) for arm,scores in p["J"].items()}
outer_wall = 432.30
assert "7:12.30" in (RAW / "native_time.txt").read_text()
cond_wall = s["arms"]["COND"]["elapsed_wall"]
dense_wall = outer_wall-cond_wall
assert cond_wall <= 600 and dense_wall <= 900 and outer_wall <= 1500
analysis = {
    "unit":"one independently trained matched pair; 32 worlds conditional on that pair",
    "launch_sha":s["launch_sha"], "provenance_source_sha":s["source_sha"],
    "checks":{"all_native_hashes_match_remote":True, "all_episode_rows_equal_summary":True,
              "master_rng_reset_and_endpoint_binding":True, "all_rollouts_and_optimizer_counts":True,
              "nonzero_all_recorded_parameter_groups":True, "checkpoint_zip_crc":True,
              "accepted_pure_reducer_equals_closed_primary":True, "native_caps_pass":True},
    "episode_rows":len(rows), "rollout_rows":len(rollouts), "counts":s["counts"],
    "mean_J":means, "primary":p, "conditional_sd":statistics.stdev(delta),
    "positive_worlds":sum(d>0 for d in delta), "adverse_worlds":sum(d<0 for d in delta),
    "zero_worlds":sum(d==0 for d in delta), "min_delta":min(delta), "max_delta":max(delta),
    "native_cost_seconds":{"COND":cond_wall, "DENSE_including_outer_tail":dense_wall,
                           "pair":outer_wall, "python_last_clock":s["pair_elapsed_wall"],
                           "outer_tail_charged_to_DENSE":outer_wall-s["pair_elapsed_wall"],
                           "cpu_user":425.74, "cpu_system":4.96, "cpu_sum":430.70},
    "peak_rss_kib":559924,
    "support_seconds":None, "complete_cost_seconds":None,
    "support_limit_seconds":900, "complete_limit_seconds":2400,
    "support_complete_compliance":"UNKNOWN: unmeasured author/provider, coordination and integration tails remain included in scope",
    "new_scientific_execution_for_intake":False,
}
save("INTAKE_ANALYSIS.json", analysis)
save("RUN_SUMMARY.json", {k:v for k,v in s.items() if k != "rows"})
with (OUT / "PAIRED_FINAL_SCORES.csv").open("w", newline="", encoding="utf-8") as f:
    w=csv.writer(f); w.writerow(["master","episode","reset_seed","COND_J","DENSE_J","COND_minus_DENSE"])
    w.writerows([8231,e,base+2000+e,p["J"]["COND"][e],p["J"]["DENSE"][e],delta[e]] for e in range(32))
with (OUT / "RUN_SCORES.csv").open("w", newline="", encoding="utf-8") as f:
    w=csv.writer(f); w.writerow(["task","seed","arm","score"])
    w.writerows([s["object"],8231,arm,value] for arm,value in means.items())
spec=importlib.util.spec_from_file_location("run_summary", ROOT / ".agents/skills/hmasd-scientific-tools/scripts/summarize_runs.py")
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
save("RUN_LEVEL_DESCRIPTIVE.json", mod.summarize(OUT / "RUN_SCORES.csv", "DENSE", paired=True))

members = [RAW / name for name in EXPECTED] + sorted((RAW / "supervisor").iterdir()) + [Path(__file__)]
archive=OUT / "NATIVE_EVIDENCE.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in members:
        z.write(path, path.relative_to(RAW).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for path in members:
        assert hashlib.sha256(z.read(path.relative_to(RAW).as_posix())).hexdigest() == digest(path)["sha256"]
save("COLLECTION.json", {"archive":digest(archive), "files":{p.relative_to(RAW).as_posix():digest(p) for p in members},
                         "native_remote_hash_match":True, "member_readback_hash_match":True,
                         "remote_output":"/home/wu/hmasd-worktrees/mgtap-unequal-8231-ecf40e0ad/temp/directions/metric_ground_transport_allocation/exp/unequal_exposure_b01_8231_20260913",
                         "no_source_or_evidence_removed":True})
print(json.dumps({k:v for k,v in analysis.items() if k not in ("primary","counts")},indent=2))
print("ARCHIVE", json.dumps(digest(archive)))
