#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/mgtap-unequal-8231-ecf40e0ad/pid"
START_TS=$(date +%s)
echo "=== Task 'mgtap-unequal-8231-ecf40e0ad' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/mgtap-unequal-8231-ecf40e0ad/task.log"

# Execute command capturing output
set +e
eval 'cd /home/wu/hmasd-worktrees/mgtap-unequal-8231-ecf40e0ad && mkdir -p /home/wu/hmasd-worktrees/mgtap-unequal-8231-ecf40e0ad/temp/directions/metric_ground_transport_allocation/exp/unequal_exposure_b01_8231_20260913 && export MGTAP_CHAIN_STARTED_UNIX=$(date +%s.%N) && /usr/bin/time -v -o /home/wu/hmasd-worktrees/mgtap-unequal-8231-ecf40e0ad/temp/directions/metric_ground_transport_allocation/exp/unequal_exposure_b01_8231_20260913/native_time.txt /usr/bin/timeout 1500 /bin/bash -lc '\''/home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out /home/wu/hmasd-worktrees/mgtap-unequal-8231-ecf40e0ad/temp/directions/metric_ground_transport_allocation/exp/unequal_exposure_b01_8231_20260913/resource_admission.json && /home/wu/.venvs/hmasd/bin/python -u scripts/run_mgtap_unequal_exposure_b01.py --seed 8231 --out /home/wu/hmasd-worktrees/mgtap-unequal-8231-ecf40e0ad/temp/directions/metric_ground_transport_allocation/exp/unequal_exposure_b01_8231_20260913'\''' >> "/home/wu/.agent-tasks/mgtap-unequal-8231-ecf40e0ad/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/mgtap-unequal-8231-ecf40e0ad/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/mgtap-unequal-8231-ecf40e0ad/status"
else
    echo "failed" > "/home/wu/.agent-tasks/mgtap-unequal-8231-ecf40e0ad/status"
fi
echo "=== Task 'mgtap-unequal-8231-ecf40e0ad' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/mgtap-unequal-8231-ecf40e0ad/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
