#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/mgtap-late-exposure-b01-8254-20260914/pid"
START_TS=$(date +%s)
echo "=== Task 'mgtap-late-exposure-b01-8254-20260914' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/mgtap-late-exposure-b01-8254-20260914/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/mgtap-late-exposure-b01-8254-20260914/docs/research/candidates/metric_ground_transport_allocation/late_exposure_b01_8254/COMMAND.sh' >> "/home/wu/.agent-tasks/mgtap-late-exposure-b01-8254-20260914/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/mgtap-late-exposure-b01-8254-20260914/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/mgtap-late-exposure-b01-8254-20260914/status"
else
    echo "failed" > "/home/wu/.agent-tasks/mgtap-late-exposure-b01-8254-20260914/status"
fi
echo "=== Task 'mgtap-late-exposure-b01-8254-20260914' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/mgtap-late-exposure-b01-8254-20260914/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
