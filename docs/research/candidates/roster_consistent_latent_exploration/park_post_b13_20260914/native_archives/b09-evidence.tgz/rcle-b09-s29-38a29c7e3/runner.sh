#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/rcle-b09-s29-38a29c7e3/pid"
START_TS=$(date +%s)
echo "=== Task 'rcle-b09-s29-38a29c7e3' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/rcle-b09-s29-38a29c7e3/task.log"

# Execute command capturing output
set +e
eval '/usr/bin/time -f '\''whole_native_wall_s=%e\npeak_rss_kib=%M\nexit_code=%x'\'' -o /home/wu/hmasd-worktrees/rcle-b09-38a29c7e3/temp/directions/roster_consistent_latent_exploration/exp/b09_control/native.time timeout --signal=TERM --kill-after=1s 179s bash -lc '\''cd /home/wu/hmasd-worktrees/rcle-b09-38a29c7e3 && export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out temp/directions/roster_consistent_latent_exploration/exp/b09_control/admission.json && /home/wu/.venvs/hmasd/bin/python scripts/run_rcle_joint_quota_phase.py --object b09 --seed 29 --out temp/directions/roster_consistent_latent_exploration/exp/b09_seed29 --launch-sha 38a29c7e3ee55cfb6fa732bdb02a271e835b45b5'\''' >> "/home/wu/.agent-tasks/rcle-b09-s29-38a29c7e3/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/rcle-b09-s29-38a29c7e3/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/rcle-b09-s29-38a29c7e3/status"
else
    echo "failed" > "/home/wu/.agent-tasks/rcle-b09-s29-38a29c7e3/status"
fi
echo "=== Task 'rcle-b09-s29-38a29c7e3' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/rcle-b09-s29-38a29c7e3/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
