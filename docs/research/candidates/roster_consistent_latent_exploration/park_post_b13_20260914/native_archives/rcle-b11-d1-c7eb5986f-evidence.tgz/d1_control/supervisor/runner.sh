#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/rcle-b11-d1-c7eb5986f/pid"
START_TS=$(date +%s)
echo "=== Task 'rcle-b11-d1-c7eb5986f' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/rcle-b11-d1-c7eb5986f/task.log"

# Execute command capturing output
set +e
eval $'/usr/bin/time -f \'diagnostic_wall_s=%e\npeak_rss_kib=%M\nexit_code=%x\' -o /home/wu/hmasd-worktrees/rcle-b11-d1-c7eb5986f/temp/directions/roster_consistent_latent_exploration/exp/d1_control/native.time timeout --signal=TERM --kill-after=10s 300s bash -lc \'cd /home/wu/hmasd-worktrees/rcle-b11-d1-c7eb5986f && export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out /home/wu/hmasd-worktrees/rcle-b11-d1-c7eb5986f/temp/directions/roster_consistent_latent_exploration/exp/d1_control/admission.json && gdb --batch --return-child-result -ex \'"\'"\'set pagination off\'"\'"\' -ex run -ex \'"\'"\'info sharedlibrary\'"\'"\' -ex \'"\'"\'info proc mappings\'"\'"\' -ex \'"\'"\'thread apply all bt 40\'"\'"\' --args /home/wu/.venvs/hmasd/bin/python -X faulthandler scripts/diagnose_rcle_b11_native_fault.py --out /home/wu/hmasd-worktrees/rcle-b11-d1-c7eb5986f/temp/directions/roster_consistent_latent_exploration/exp/d1\'' >> "/home/wu/.agent-tasks/rcle-b11-d1-c7eb5986f/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/rcle-b11-d1-c7eb5986f/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/rcle-b11-d1-c7eb5986f/status"
else
    echo "failed" > "/home/wu/.agent-tasks/rcle-b11-d1-c7eb5986f/status"
fi
echo "=== Task 'rcle-b11-d1-c7eb5986f' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/rcle-b11-d1-c7eb5986f/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
