#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/rcle-b10-s30-e5fd43973/pid"
START_TS=$(date +%s)
echo "=== Task 'rcle-b10-s30-e5fd43973' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/rcle-b10-s30-e5fd43973/task.log"

# Execute command capturing output
set +e
eval '/usr/bin/time -f '\''whole_native_wall_s=%e\npeak_rss_kib=%M\nexit_code=%x'\'' -o /home/wu/hmasd-worktrees/rcle-b10-e5fd43973/temp/directions/roster_consistent_latent_exploration/exp/b10_control/native.time timeout --signal=TERM --kill-after=1s 298s bash -lc '\''cd /home/wu/hmasd-worktrees/rcle-b10-e5fd43973 && export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out temp/directions/roster_consistent_latent_exploration/exp/b10_control/admission.json && /home/wu/.venvs/hmasd/bin/python scripts/run_rcle_joint_quota_phase.py --object b10 --seed 30 --out temp/directions/roster_consistent_latent_exploration/exp/b10_seed30 --launch-sha e5fd439735bcc52d7f4cba9943b8c5c5138e21c2'\''' >> "/home/wu/.agent-tasks/rcle-b10-s30-e5fd43973/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/rcle-b10-s30-e5fd43973/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/rcle-b10-s30-e5fd43973/status"
else
    echo "failed" > "/home/wu/.agent-tasks/rcle-b10-s30-e5fd43973/status"
fi
echo "=== Task 'rcle-b10-s30-e5fd43973' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/rcle-b10-s30-e5fd43973/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
