#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/rcle-modal-e01-5c3ab7b07/pid"
START_TS=$(date +%s)
echo "=== Task 'rcle-modal-e01-5c3ab7b07' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/rcle-modal-e01-5c3ab7b07/task.log"

# Execute command capturing output
set +e
eval $'/usr/bin/time -f \'whole_native_wall_s=%e\r\npeak_rss_kib=%M\r\nexit_code=%x\' -o /home/wu/hmasd-worktrees/rcle-modal-e01-5c3ab7b07/temp/directions/roster_consistent_latent_exploration/exp/modal_e01_control/native.time timeout --signal=TERM --kill-after=10s 600s bash -lc \'cd /home/wu/hmasd-worktrees/rcle-modal-e01-5c3ab7b07 && export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out /home/wu/hmasd-worktrees/rcle-modal-e01-5c3ab7b07/temp/directions/roster_consistent_latent_exploration/exp/modal_e01_control/admission.json && gdb --batch --return-child-result -ex \'"\'"\'set pagination off\'"\'"\' -ex run -ex \'"\'"\'info sharedlibrary\'"\'"\' -ex \'"\'"\'info proc mappings\'"\'"\' -ex \'"\'"\'thread apply all bt 40\'"\'"\' --args /home/wu/.venvs/hmasd/bin/python -X faulthandler scripts/run_rcle_fixed_modal_reuse_e01.py --inputs /home/wu/hmasd-inputs/rcle-fixed-modal-e01-20260914/inputs --out /home/wu/hmasd-worktrees/rcle-modal-e01-5c3ab7b07/temp/directions/roster_consistent_latent_exploration/exp/modal_e01 --launch-sha 5c3ab7b074f185902078452811774e6a8d727a9d\'' >> "/home/wu/.agent-tasks/rcle-modal-e01-5c3ab7b07/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/rcle-modal-e01-5c3ab7b07/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/rcle-modal-e01-5c3ab7b07/status"
else
    echo "failed" > "/home/wu/.agent-tasks/rcle-modal-e01-5c3ab7b07/status"
fi
echo "=== Task 'rcle-modal-e01-5c3ab7b07' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/rcle-modal-e01-5c3ab7b07/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
