#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/rcle-b11-s31-e863914e2-launch02/pid"
START_TS=$(date +%s)
echo "=== Task 'rcle-b11-s31-e863914e2-launch02' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/rcle-b11-s31-e863914e2-launch02/task.log"

# Execute command capturing output
set +e
eval '/usr/bin/time -f '\''whole_native_wall_s=%e\npeak_rss_kib=%M\nexit_code=%x'\'' -o /home/wu/hmasd-worktrees/rcle-b11-e863914e2/temp/directions/roster_consistent_latent_exploration/exp/b11_control/native.time timeout --signal=TERM --kill-after=10s 1800s bash -lc '\''cd /home/wu/hmasd-worktrees/rcle-b11-e863914e2 && export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out /home/wu/hmasd-worktrees/rcle-b11-e863914e2/temp/directions/roster_consistent_latent_exploration/exp/b11_control/admission.json && /home/wu/.venvs/hmasd/bin/python scripts/run_rcle_joint_quota_phase.py --object b11 --seed 31 --out /home/wu/hmasd-worktrees/rcle-b11-e863914e2/temp/directions/roster_consistent_latent_exploration/exp/b11_seed31 --launch-sha e863914e2c2c071b8dbdd8787f159233245000d5'\''' >> "/home/wu/.agent-tasks/rcle-b11-s31-e863914e2-launch02/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/rcle-b11-s31-e863914e2-launch02/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/rcle-b11-s31-e863914e2-launch02/status"
else
    echo "failed" > "/home/wu/.agent-tasks/rcle-b11-s31-e863914e2-launch02/status"
fi
echo "=== Task 'rcle-b11-s31-e863914e2-launch02' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/rcle-b11-s31-e863914e2-launch02/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
