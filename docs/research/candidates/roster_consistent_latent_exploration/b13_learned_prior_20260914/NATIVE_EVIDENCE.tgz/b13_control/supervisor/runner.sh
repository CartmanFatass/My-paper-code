#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/rcle-b13-s33-cf4d9bd93/pid"
START_TS=$(date +%s)
echo "=== Task 'rcle-b13-s33-cf4d9bd93' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/rcle-b13-s33-cf4d9bd93/task.log"

# Execute command capturing output
set +e
eval $'/usr/bin/time -f \'whole_native_wall_s=%e\npeak_rss_kib=%M\nexit_code=%x\' -o /home/wu/hmasd-worktrees/rcle-b13-cf4d9bd93/temp/directions/roster_consistent_latent_exploration/exp/b13_control/native.time timeout --signal=TERM --kill-after=10s 1800s bash -lc \'cd /home/wu/hmasd-worktrees/rcle-b13-cf4d9bd93 && export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out /home/wu/hmasd-worktrees/rcle-b13-cf4d9bd93/temp/directions/roster_consistent_latent_exploration/exp/b13_control/admission.json && gdb --batch --return-child-result -ex \'"\'"\'set pagination off\'"\'"\' -ex run -ex \'"\'"\'info sharedlibrary\'"\'"\' -ex \'"\'"\'info proc mappings\'"\'"\' -ex \'"\'"\'thread apply all bt 40\'"\'"\' --args /home/wu/.venvs/hmasd/bin/python -X faulthandler scripts/run_rcle_learned_prior_b13.py --seed 33 --out /home/wu/hmasd-worktrees/rcle-b13-cf4d9bd93/temp/directions/roster_consistent_latent_exploration/exp/b13_seed33 --launch-sha cf4d9bd93ff9eb255800223d95de170b68315ba6\'' >> "/home/wu/.agent-tasks/rcle-b13-s33-cf4d9bd93/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/rcle-b13-s33-cf4d9bd93/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/rcle-b13-s33-cf4d9bd93/status"
else
    echo "failed" > "/home/wu/.agent-tasks/rcle-b13-s33-cf4d9bd93/status"
fi
echo "=== Task 'rcle-b13-s33-cf4d9bd93' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/rcle-b13-s33-cf4d9bd93/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
