#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/cbsc-public-stream-b01-20260912/pid"
START_TS=$(date +%s)
echo "=== Task 'cbsc-public-stream-b01-20260912' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/cbsc-public-stream-b01-20260912/task.log"

# Execute command capturing output
set +e
eval 'cd /home/wu/hmasd-worktrees/cbsc-public-stream-b01-20260912 && ulimit -c 0 && /usr/bin/time -f '\''ELAPSED_SECONDS=%e USER_SECONDS=%U SYSTEM_SECONDS=%S PEAK_RSS_KIB=%M EXIT=%x'\'' -o temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/raw.time /usr/bin/timeout --signal=TERM --kill-after=5s 590s bash -lc '\''env PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 /home/wu/.venvs/hmasd/bin/python -B scripts/hmasd_resource_preflight.py admit-memory --out temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/raw-admission.json && exec env PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 /home/wu/.venvs/hmasd/bin/python -B scripts/run_cbsc_public_stream_b01.py --arm RAW-GRU --seed 2026091231 --output temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/raw'\'' > temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/raw.log 2>&1 && /usr/bin/time -f '\''ELAPSED_SECONDS=%e USER_SECONDS=%U SYSTEM_SECONDS=%S PEAK_RSS_KIB=%M EXIT=%x'\'' -o temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/struct.time /usr/bin/timeout --signal=TERM --kill-after=5s 590s bash -lc '\''env PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 /home/wu/.venvs/hmasd/bin/python -B scripts/hmasd_resource_preflight.py admit-memory --out temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/struct-admission.json && exec env PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 /home/wu/.venvs/hmasd/bin/python -B scripts/run_cbsc_public_stream_b01.py --arm STRUCT-CURRENTNESS-GRU --seed 2026091231 --output temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/struct --raw-result temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/raw/summary.json'\'' > temp/directions/capability_bound_semantic_currentness/exp/cbsc-public-stream-b01-20260912/struct.log 2>&1' >> "/home/wu/.agent-tasks/cbsc-public-stream-b01-20260912/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/cbsc-public-stream-b01-20260912/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/cbsc-public-stream-b01-20260912/status"
else
    echo "failed" > "/home/wu/.agent-tasks/cbsc-public-stream-b01-20260912/status"
fi
echo "=== Task 'cbsc-public-stream-b01-20260912' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/cbsc-public-stream-b01-20260912/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
