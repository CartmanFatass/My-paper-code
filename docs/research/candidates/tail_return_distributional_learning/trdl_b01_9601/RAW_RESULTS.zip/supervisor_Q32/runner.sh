#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/trdl-b01-9601-q32/pid"
START_TS=$(date +%s)
echo "=== Task 'trdl-b01-9601-q32' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/trdl-b01-9601-q32/task.log"

# Execute command capturing output
set +e
eval 'cd /home/wu/hmasd-worktrees/trdl-b01-9601 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out /home/wu/hmasd-worktrees/trdl-b01-9601/temp/directions/tail_return_distributional_learning/exp/b01_9601/Q32_ADMISSION.json && /usr/bin/time -q -f '\''{"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S,"peak_rss_kib":%M,"exit_code":%x}'\'' -o /home/wu/hmasd-worktrees/trdl-b01-9601/temp/directions/tail_return_distributional_learning/exp/b01_9601/Q32_INVOCATION_TIME.json /home/wu/.venvs/hmasd/bin/python -u scripts/run_trdl_b01.py arm --arm Q32 --seed 9601 --out /home/wu/hmasd-worktrees/trdl-b01-9601/temp/directions/tail_return_distributional_learning/exp/b01_9601/Q32 --launch-sha 0874ccfb6102859e5cd7ecfbc4b7d578eab06d91 --max-seconds 7200' >> "/home/wu/.agent-tasks/trdl-b01-9601-q32/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/trdl-b01-9601-q32/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/trdl-b01-9601-q32/status"
else
    echo "failed" > "/home/wu/.agent-tasks/trdl-b01-9601-q32/status"
fi
echo "=== Task 'trdl-b01-9601-q32' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/trdl-b01-9601-q32/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
