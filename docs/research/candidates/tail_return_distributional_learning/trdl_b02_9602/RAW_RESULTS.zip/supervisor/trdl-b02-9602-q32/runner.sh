#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/trdl-b02-9602-q32/pid"
START_TS=$(date +%s)
echo "=== Task 'trdl-b02-9602-q32' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/trdl-b02-9602-q32/task.log"

# Execute command capturing output
set +e
eval 'cd /home/wu/hmasd-worktrees/trdl-b02-9602 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out /home/wu/hmasd-worktrees/trdl-b02-9602/temp/directions/tail_return_distributional_learning/exp/b02_9602/Q32_ADMISSION.json && /usr/bin/time -q -f '\''{"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S,"peak_rss_kib":%M,"exit_code":%x}'\'' -o /home/wu/hmasd-worktrees/trdl-b02-9602/temp/directions/tail_return_distributional_learning/exp/b02_9602/Q32_INVOCATION_TIME.json /home/wu/.venvs/hmasd/bin/python -u scripts/run_trdl_b01.py arm --arm Q32 --seed 9602 --out /home/wu/hmasd-worktrees/trdl-b02-9602/temp/directions/tail_return_distributional_learning/exp/b02_9602/Q32 --launch-sha deddd8d9e0b41cff165d32f3f7729c23df236a69 --max-seconds 900' >> "/home/wu/.agent-tasks/trdl-b02-9602-q32/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/trdl-b02-9602-q32/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/trdl-b02-9602-q32/status"
else
    echo "failed" > "/home/wu/.agent-tasks/trdl-b02-9602-q32/status"
fi
echo "=== Task 'trdl-b02-9602-q32' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/trdl-b02-9602-q32/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
