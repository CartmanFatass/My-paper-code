#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/fsd-ib-b01-772003-I128/pid"
START_TS=$(date +%s)
echo "=== Task 'fsd-ib-b01-772003-I128' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/fsd-ib-b01-772003-I128/task.log"

# Execute command capturing output
set +e
eval '/bin/bash /home/wu/hmasd-worktrees/fsd-interruption-batch-b01-20260914/docs/research/candidates/flexible_skill_duration/interruption_batch_b01_20260914/commands/FIT.sh I128 772003' >> "/home/wu/.agent-tasks/fsd-ib-b01-772003-I128/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/fsd-ib-b01-772003-I128/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/fsd-ib-b01-772003-I128/status"
else
    echo "failed" > "/home/wu/.agent-tasks/fsd-ib-b01-772003-I128/status"
fi
echo "=== Task 'fsd-ib-b01-772003-I128' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/fsd-ib-b01-772003-I128/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
