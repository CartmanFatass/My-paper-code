"""Read both preserved selected endpoints without new native acquisition."""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import math
import statistics
import sys

sys.path.insert(0, str(Path.cwd()))
from experiments.candidates.vap_folr_core.entity_current_increment_b01.publication import pair_result

p = Path("docs/research/candidates/vap_folr_core/entity_current_increment_b01_781801")
g = json.loads((p / "GENERIC_SUMMARY.json").read_bytes())
z = json.loads((p / "CURRENT_ONLY_SUMMARY.json").read_bytes())
gc = json.loads((p / "GENERIC_COLLECTION.json").read_bytes())
zc = json.loads((p / "CURRENT_ONLY_COLLECTION.json").read_bytes())
assert not gc["errors"] and not zc["errors"]
assert zc["generic_input_sha256"] == gc["summary_sha256"]
assert z["generic_input"] == gc["out"] + "/summary.json"
panels = {}
for name, summary, collection in [("GENERIC", g, gc), ("CURRENT_ONLY", z, zc)]:
    raw = (p / (name + "_SUMMARY.json")).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == collection["summary_sha256"]
    assert summary["training_identity_kind"] == "fresh_unscreened_fit"
    assert summary["final_checkpoint"] == collection["out"] + "/final.pt"
    assert summary["actor_change_l2"] > 0
    values = summary["evaluation_returns"]
    panel = {
        "mean": statistics.mean(values), "sample_sd": statistics.stdev(values),
        "conditional_episode_se": statistics.stdev(values) / math.sqrt(len(values)),
        "minimum": min(values), "maximum": max(values), "n": len(values),
        "negative_count": sum(x < 0 for x in values),
    }
    assert all(math.isclose(value, summary["native_panel"][key], rel_tol=1e-12, abs_tol=1e-12)
               for key, value in panel.items())
    assert math.isclose(panel["mean"], summary["mean_native_return"], rel_tol=1e-12, abs_tol=1e-12)
    panels[name] = panel
primary = pair_result(g, z)
assert primary == z["pair_primary"]
counts = {key: g[key] + z[key] for key in (
    "training_episodes", "training_ticks", "optimizer_steps", "evaluation_episodes", "evaluation_ticks")}
cost = {
    "native_wall_sum_seconds": sum(c["invocation_time"]["wall_seconds"] for c in (gc, zc)),
    "aggregate_cpu_sum_seconds": sum(c["invocation_time"]["user_seconds"] + c["invocation_time"]["system_seconds"] for c in (gc, zc)),
    "peak_rss_kib_max": max(c["invocation_time"]["peak_rss_kib"] for c in (gc, zc)),
    "support_provider_lifetime_total": "UNKNOWN",
}
record = {
    "readback_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_sha": z["launch_sha"], "primary_recomputed": primary,
    "recomputed_panels": panels, "complete_counts": counts, "new_training_instances": 2,
    "per_arm_actor_change_l2": {"G": g["actor_change_l2"], "Z": z["actor_change_l2"]},
    "exposure_line": f"2 fresh fits; {counts['training_ticks']} native training ticks; {counts['optimizer_steps']} RMSprop steps; 2 final checkpoints; {counts['evaluation_episodes']} final greedy episodes/{counts['evaluation_ticks']} evaluation ticks; no screening/retry/checkpoint selection",
    "cost": cost, "training_population_uncertainty": "not estimated",
    "paired_world_or_arm_independence": "not established by common seed labels",
}
(p / "PAIR_READBACK.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n", encoding="utf-8")
with (p / "RUN_SCORES.csv").open("w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["task", "seed", "arm", "score"])
    for label, summary in [("G_GENERIC", g), ("Z_CURRENT_ONLY", z)]:
        writer.writerow([z["object"], summary["training_seed"], label, summary["mean_native_return"]])
print(json.dumps(record, allow_nan=False))
