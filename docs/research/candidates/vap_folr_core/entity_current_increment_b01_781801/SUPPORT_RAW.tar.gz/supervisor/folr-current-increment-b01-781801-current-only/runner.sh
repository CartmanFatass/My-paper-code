#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-current-increment-b01-781801-current-only/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-current-increment-b01-781801-current-only' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-current-increment-b01-781801-current-only/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/folr-entity-current-increment-b01-781801/temp/directions/vap_folr_core/exp/entity_current_increment_b01_781801/CURRENT_ONLY.sh 8ad304d61af6885c0ca5ba236bbf6c2c160e61f4 /home/wu/hmasd-worktrees/folr-entity-current-increment-b01-781801 /home/wu/hmasd-worktrees/folr-entity-current-increment-b01-781801/temp/directions/vap_folr_core/exp/entity_current_increment_b01_781801/current_only /home/wu/hmasd-worktrees/folr-entity-current-increment-b01-781801/temp/directions/vap_folr_core/exp/entity_current_increment_b01_781801/generic/summary.json' >> "/home/wu/.agent-tasks/folr-current-increment-b01-781801-current-only/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-current-increment-b01-781801-current-only/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-current-increment-b01-781801-current-only/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-current-increment-b01-781801-current-only/status"
fi
echo "=== Task 'folr-current-increment-b01-781801-current-only' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-current-increment-b01-781801-current-only/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
