#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-b03-781501-bank/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-b03-781501-bank' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-b03-781501-bank/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/folr-entity-history-b03-781501-b257dcb1d/temp/directions/vap_folr_core/exp/entity_history_b03_781501/BANK_LAUNCH.sh b257dcb1d7578a057afa9b4bdd7c7ff74ad8e24f /home/wu/hmasd-worktrees/folr-entity-history-b03-781501-b257dcb1d /home/wu/hmasd-worktrees/folr-entity-history-b03-781501-b257dcb1d/temp/directions/vap_folr_core/exp/entity_history_b03_781501/BANK /home/wu/hmasd-worktrees/folr-entity-history-b03-781501-b257dcb1d/temp/directions/vap_folr_core/exp/entity_history_b03_781501/GENERIC/summary.json' >> "/home/wu/.agent-tasks/folr-b03-781501-bank/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-b03-781501-bank/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-b03-781501-bank/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-b03-781501-bank/status"
fi
echo "=== Task 'folr-b03-781501-bank' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-b03-781501-bank/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
