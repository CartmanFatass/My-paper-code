#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-b03-781501-generic/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-b03-781501-generic' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-b03-781501-generic/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/folr-entity-history-b03-781501-b257dcb1d/temp/directions/vap_folr_core/exp/entity_history_b03_781501/GENERIC_LAUNCH.sh b257dcb1d7578a057afa9b4bdd7c7ff74ad8e24f /home/wu/hmasd-worktrees/folr-entity-history-b03-781501-b257dcb1d /home/wu/hmasd-worktrees/folr-entity-history-b03-781501-b257dcb1d/temp/directions/vap_folr_core/exp/entity_history_b03_781501/GENERIC' >> "/home/wu/.agent-tasks/folr-b03-781501-generic/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-b03-781501-generic/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-b03-781501-generic/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-b03-781501-generic/status"
fi
echo "=== Task 'folr-b03-781501-generic' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-b03-781501-generic/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
