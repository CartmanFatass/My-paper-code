#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-learned-retention-b03-learned-event-20260911/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-learned-retention-b03-learned-event-20260911' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-learned-retention-b03-learned-event-20260911/task.log"

# Execute command capturing output
set +e
eval 'cd /home/wu/hmasd-worktrees/folr-learned-retention-b03-89035d8f1 && mkdir -p temp/directions/vap_folr_core/exp && /usr/bin/time -v -o temp/directions/vap_folr_core/exp/learned_retention_b03_seed7811_learned_event_whole_time.txt /usr/bin/timeout --signal=TERM --kill-after=5s 1340s bash -lc '\''/home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out temp/directions/vap_folr_core/exp/learned_retention_b03_seed7811_learned_event_memory.json && /home/wu/.venvs/hmasd/bin/python -B scripts/run_folr_public_lifecycle_b01.py --arm LEARNED_EVENT --seed 7811 --evaluation-seed 107811 --launch-sha 89035d8f1e3f44a07e80c08e3140283c03592efb --out temp/directions/vap_folr_core/exp/learned_retention_b03_seed7811_learned_event'\''' >> "/home/wu/.agent-tasks/folr-learned-retention-b03-learned-event-20260911/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-learned-retention-b03-learned-event-20260911/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-learned-retention-b03-learned-event-20260911/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-learned-retention-b03-learned-event-20260911/status"
fi
echo "=== Task 'folr-learned-retention-b03-learned-event-20260911' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-learned-retention-b03-learned-event-20260911/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
