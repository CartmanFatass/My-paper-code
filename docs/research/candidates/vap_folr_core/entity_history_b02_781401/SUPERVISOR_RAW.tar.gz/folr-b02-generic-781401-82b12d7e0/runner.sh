#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-b02-generic-781401-82b12d7e0/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-b02-generic-781401-82b12d7e0' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-b02-generic-781401-82b12d7e0/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/folr-entity-history-b02-781401-82b12d7e0/docs/research/candidates/vap_folr_core/entity_history_b02_781401/GENERIC.sh 82b12d7e0f205ea228ca69e28e581ca6ee5f2ca6 /home/wu/hmasd-worktrees/folr-entity-history-b02-781401-82b12d7e0 /home/wu/hmasd-worktrees/folr-entity-history-b02-781401-82b12d7e0/experiments/results/folr_entity_history_b02_781401/GENERIC_RETAIN' >> "/home/wu/.agent-tasks/folr-b02-generic-781401-82b12d7e0/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-b02-generic-781401-82b12d7e0/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-b02-generic-781401-82b12d7e0/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-b02-generic-781401-82b12d7e0/status"
fi
echo "=== Task 'folr-b02-generic-781401-82b12d7e0' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-b02-generic-781401-82b12d7e0/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
