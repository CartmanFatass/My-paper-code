"""Read the two selected preserved endpoints; no new native acquisition."""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import math
import statistics
import sys

sys.path.insert(0, str(Path.cwd()))
from experiments.candidates.vap_folr_core.entity_persistence_b01.publication import pair_result

p = Path('docs/research/candidates/vap_folr_core/entity_persistence_b01_781701')
z = json.loads((p / 'CURRENT_ONLY_SUMMARY.json').read_text())
a = json.loads((p / 'PERSISTENT_SUMMARY.json').read_text())
z_collection = json.loads((p / 'CURRENT_ONLY_COLLECTION.json').read_text())
a_collection = json.loads((p / 'PERSISTENT_COLLECTION.json').read_text())
assert not z_collection['errors'] and not a_collection['errors']
assert a_collection['current_only_input_sha256'] == z_collection['summary_sha256']
assert a['current_only_input'] == z_collection['out'] + '/summary.json'
for name, summary, collection in [('CURRENT_ONLY', z, z_collection), ('PERSISTENT', a, a_collection)]:
    raw = (p / (name + '_SUMMARY.json')).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == collection['summary_sha256']
    assert summary['training_identity_kind'] == 'fresh_unscreened_fit'
    assert summary['final_checkpoint'] == collection['out'] + '/final.pt'
    assert summary['actor_change_l2'] > 0
v = a['evaluation_returns']
recomputed_a = {
    'mean': statistics.mean(v), 'sample_sd': statistics.stdev(v),
    'conditional_episode_se': statistics.stdev(v) / math.sqrt(len(v)),
    'minimum': min(v), 'maximum': max(v), 'n': len(v),
    'negative_count': sum(x < 0 for x in v),
}
assert all(math.isclose(x, a['native_panel'][k], rel_tol=1e-12, abs_tol=1e-12)
           for k, x in recomputed_a.items())
assert math.isclose(recomputed_a['mean'], a['mean_native_return'], rel_tol=1e-12, abs_tol=1e-12)
primary = pair_result(z, a)
assert primary == a['pair_primary']
counts = {key: z[key] + a[key] for key in (
    'training_episodes', 'training_ticks', 'optimizer_steps',
    'evaluation_episodes', 'evaluation_ticks')}
cost = {
    'native_wall_sum_seconds': sum(c['invocation_time']['wall_seconds'] for c in (z_collection, a_collection)),
    'aggregate_cpu_sum_seconds': sum(c['invocation_time']['user_seconds'] + c['invocation_time']['system_seconds'] for c in (z_collection, a_collection)),
    'peak_rss_kib_max': max(c['invocation_time']['peak_rss_kib'] for c in (z_collection, a_collection)),
    'support_provider_lifetime_total': 'UNKNOWN',
}
record = {
    'readback_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_sha': a['launch_sha'], 'primary_recomputed': primary,
    'recomputed_persistent_panel': recomputed_a, 'complete_counts': counts,
    'new_training_instances': 2, 'per_arm_actor_change_l2': {
        'Z': z['actor_change_l2'], 'A': a['actor_change_l2']},
    'exposure_line': f"2 fresh fits; {counts['training_ticks']} native training ticks; {counts['optimizer_steps']} RMSprop steps; 2 final checkpoints; {counts['evaluation_episodes']} final greedy episodes/{counts['evaluation_ticks']} evaluation ticks; no screening/retry/checkpoint selection",
    'cost': cost, 'training_population_uncertainty': 'not estimated',
    'paired_world_or_arm_independence': 'not established by common seed labels',
}
(p / 'PAIR_READBACK.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n', encoding='utf-8')
with (p / 'RUN_SCORES.csv').open('w', encoding='utf-8', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['task', 'seed', 'arm', 'score'])
    for label, summary in [('Z_CURRENT_ONLY', z), ('A_PERSISTENT', a)]:
        writer.writerow([a['object'], summary['training_seed'], label, summary['mean_native_return']])
print(json.dumps(record, allow_nan=False))
