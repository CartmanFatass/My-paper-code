"""One terminal arm's collection; executed on the declared remote source checkout."""
from pathlib import Path
import datetime,hashlib,json,math,subprocess,tarfile,sys
import torch

mode=sys.argv[1]
if mode not in ('current_only','persistent'): raise ValueError(mode)
torch.set_num_threads(1)
expected_arm='AUGMENTED_CURRENT_ONLY' if mode=='current_only' else 'AUGMENTED_PERSISTENT'
sha='42e337f36bd36c5dd24a7862eb71144f44fdef57'
wt=Path('/home/wu/hmasd-worktrees/folr-entity-persistence-b01-781701-bd841a180')
base=wt/'temp/directions/vap_folr_core/exp/entity_persistence_b01_781701'
out=base/mode
name='folr-persistence-b01-781701-'+mode.replace('_','-')
status=json.loads(subprocess.check_output(['agent-task','status',name],text=True))
if status.get('exit_code') is None: raise RuntimeError('terminal collection requires terminal status')
record={'collected_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':mode,'handle':name,'source_sha':sha,'status':status,'cwd':str(wt),'out':str(out),'errors':[]}
actual=subprocess.check_output(['git','-C',str(wt),'rev-parse','HEAD'],text=True).strip()
record['actual_head']=actual
record['tracked_status']=subprocess.check_output(['git','-C',str(wt),'status','--porcelain','--untracked-files=no'],text=True)
if actual!=sha or record['tracked_status']:record['errors'].append('source checkout mismatch')
summary_path=out/'summary.json'
if summary_path.is_file():
 summary=json.loads(summary_path.read_text())
 record['summary_sha256']=hashlib.sha256(summary_path.read_bytes()).hexdigest()
 record['summary_bytes']=summary_path.stat().st_size
 record['binding']={k:summary.get(k) for k in ('object','arm','status','training_seed','evaluation_seed','launch_sha','training_episodes','training_ticks','optimizer_steps','evaluation_episodes','evaluation_ticks','actor_parameters','actor_change_l2','torch_version','numpy_version','torch_threads')}
 required={'object':'FOLR_ENTITY_PERSISTENCE_B01_781701','arm':expected_arm,'status':'complete','training_seed':781701,'evaluation_seed':1781701,'launch_sha':sha,'training_episodes':5000,'training_ticks':100000,'optimizer_steps':4969,'evaluation_episodes':128,'evaluation_ticks':2560,'actor_parameters':192741,'torch_threads':[1,1]}
 for k,v in required.items():
  if summary.get(k)!=v:record['errors'].append(k+' mismatch')
 record['array_counts']={k:len(summary.get(k,[])) for k in ('training_returns','evaluation_returns')}
 for k,n in [('training_returns',5000),('evaluation_returns',128)]:
  values=summary.get(k,[])
  if len(values)!=n or not all(isinstance(v,(float,int)) and math.isfinite(v) for v in values):record['errors'].append(k+' invalid')
 record['native_panel']=summary.get('native_panel')
 record['pair_primary']=summary.get('pair_primary')
 if mode=='persistent' and (base/'current_only/summary.json').is_file():
  record['current_only_input_sha256']=hashlib.sha256((base/'current_only/summary.json').read_bytes()).hexdigest()
else:record['errors'].append('summary missing')
checkpoint=out/'final.pt'
if checkpoint.is_file():
 state=torch.load(checkpoint,map_location='cpu',weights_only=True)
 def tensors(x):
  if torch.is_tensor(x):yield x
  elif isinstance(x,dict):
   for v in x.values():yield from tensors(v)
  elif isinstance(x,(list,tuple)):
   for v in x:yield from tensors(v)
 ts=list(tensors(state))
 record['checkpoint']={'bytes':checkpoint.stat().st_size,'sha256':hashlib.sha256(checkpoint.read_bytes()).hexdigest(),'arm':state.get('arm'),'updates':state.get('updates'),'keys':list(state),'tensor_count':len(ts),'all_finite':all(torch.isfinite(t).all().item() for t in ts),'all_cpu':all(t.device.type=='cpu' for t in ts),'floating_dtypes':sorted(set(str(t.dtype) for t in ts if t.is_floating_point())),'actor_state_elements':sum(t.numel() for t in state.get('actor',{}).values()),'target_actor_state_elements':sum(t.numel() for t in state.get('target_actor',{}).values()),'optimizer_slots':len(state.get('optimiser',{}).get('state',{}))}
 if not record['checkpoint']['all_finite'] or not record['checkpoint']['all_cpu'] or state.get('updates')!=4969 or state.get('arm')!=expected_arm or record['checkpoint']['actor_state_elements']!=192768 or record['checkpoint']['target_actor_state_elements']!=192768:record['errors'].append('checkpoint conformance')
else:record['errors'].append('checkpoint missing')
for f,k in [('INVOCATION_TIME.json','invocation_time'),('ADMISSION.json','admission')]:
 if (out/f).is_file():record[k]=json.loads((out/f).read_text())
 else:record[k]=None
if record['invocation_time'] and record['invocation_time']['exit_code']!=0:record['errors'].append('invocation exit nonzero')
if status.get('exit_code')!=0:record['errors'].append('supervisor exit nonzero')
files=[]
for p in sorted(out.rglob('*')):
 if p.is_file():files.append((p,'run/'+p.relative_to(out).as_posix()))
supervisor=Path('/home/wu/.agent-tasks')/name
for p in sorted(supervisor.rglob('*')):
 if p.is_file():files.append((p,'supervisor/'+p.relative_to(supervisor).as_posix()))
record['manifest']=[{'path':str(p),'archive_name':rel,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,rel in files]
archive=base/(mode.upper()+'_RAW.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p,rel in files:t.add(p,arcname=rel,recursive=False)
record['archive']={'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
with tarfile.open(archive,'r:gz') as t:
 record['archive_members_verified']=all(hashlib.sha256(t.extractfile(m['archive_name']).read()).hexdigest()==m['sha256'] for m in record['manifest'])
(base/(mode.upper()+'_COLLECTION.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
