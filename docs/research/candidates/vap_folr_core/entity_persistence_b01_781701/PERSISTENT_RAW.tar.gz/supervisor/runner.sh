#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-persistence-b01-781701-persistent/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-persistence-b01-781701-persistent' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-persistence-b01-781701-persistent/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/folr-entity-persistence-b01-781701-bd841a180/temp/directions/vap_folr_core/exp/entity_persistence_b01_781701/PERSISTENT.sh 42e337f36bd36c5dd24a7862eb71144f44fdef57 /home/wu/hmasd-worktrees/folr-entity-persistence-b01-781701-bd841a180 /home/wu/hmasd-worktrees/folr-entity-persistence-b01-781701-bd841a180/temp/directions/vap_folr_core/exp/entity_persistence_b01_781701/persistent /home/wu/hmasd-worktrees/folr-entity-persistence-b01-781701-bd841a180/temp/directions/vap_folr_core/exp/entity_persistence_b01_781701/current_only/summary.json' >> "/home/wu/.agent-tasks/folr-persistence-b01-781701-persistent/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-persistence-b01-781701-persistent/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-persistence-b01-781701-persistent/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-persistence-b01-781701-persistent/status"
fi
echo "=== Task 'folr-persistence-b01-781701-persistent' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-persistence-b01-781701-persistent/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
