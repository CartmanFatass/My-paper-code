#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-augmentation-b01-781601-augmented/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-augmentation-b01-781601-augmented' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-augmentation-b01-781601-augmented/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/folr-entity-history-augmentation-b01-781601-d9977dc18/temp/directions/vap_folr_core/exp/entity_history_augmentation_b01_781601/AUGMENTED_LAUNCH.sh d9977dc18baf33b78dc626764c252391f1ddaa9d /home/wu/hmasd-worktrees/folr-entity-history-augmentation-b01-781601-d9977dc18 /home/wu/hmasd-worktrees/folr-entity-history-augmentation-b01-781601-d9977dc18/temp/directions/vap_folr_core/exp/entity_history_augmentation_b01_781601/augmented_persistent /home/wu/hmasd-worktrees/folr-entity-history-augmentation-b01-781601-d9977dc18/temp/directions/vap_folr_core/exp/entity_history_augmentation_b01_781601/generic_retain/summary.json' >> "/home/wu/.agent-tasks/folr-augmentation-b01-781601-augmented/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-augmentation-b01-781601-augmented/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-augmentation-b01-781601-augmented/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-augmentation-b01-781601-augmented/status"
fi
echo "=== Task 'folr-augmentation-b01-781601-augmented' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-augmentation-b01-781601-augmented/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
