Complete two-block augmentation repetition review at commit b3f866e0d0f8c5f618dd6deab05d66e71ea83bbe

Delivery comment on issue #15