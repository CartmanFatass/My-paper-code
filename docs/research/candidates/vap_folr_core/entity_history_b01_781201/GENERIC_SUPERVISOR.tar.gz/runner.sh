#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-generic/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-entity-history-b01-781201-generic' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-entity-history-b01-781201-generic/task.log"

# Execute command capturing output
set +e
eval '/bin/bash /home/wu/hmasd-worktrees/folr-entity-history-b01-781201-5d511b304/temp/directions/vap_folr_core/exp/entity_history_b01_781201_support/GENERIC.sh 922a461fde867a8efe23a1563a969e6d2d08e258 /home/wu/hmasd-worktrees/folr-entity-history-b01-781201-5d511b304 /home/wu/hmasd-worktrees/folr-entity-history-b01-781201-5d511b304/temp/directions/vap_folr_core/exp/entity_history_b01_781201_generic' >> "/home/wu/.agent-tasks/folr-entity-history-b01-781201-generic/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-generic/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-generic/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-generic/status"
fi
echo "=== Task 'folr-entity-history-b01-781201-generic' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-entity-history-b01-781201-generic/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
