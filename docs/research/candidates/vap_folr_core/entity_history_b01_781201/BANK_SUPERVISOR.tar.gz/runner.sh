#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-bank/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-entity-history-b01-781201-bank' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-entity-history-b01-781201-bank/task.log"

# Execute command capturing output
set +e
eval '/bin/bash /home/wu/hmasd-worktrees/folr-entity-history-b01-781201-5d511b304/temp/directions/vap_folr_core/exp/entity_history_b01_781201_support/BANK.sh 5b3ae6b9847beba5fe72b0960ec7b66cb7d1c4b4 /home/wu/hmasd-worktrees/folr-entity-history-b01-781201-5d511b304 /home/wu/hmasd-worktrees/folr-entity-history-b01-781201-5d511b304/temp/directions/vap_folr_core/exp/entity_history_b01_781201_bank /home/wu/hmasd-worktrees/folr-entity-history-b01-781201-5d511b304/temp/directions/vap_folr_core/exp/entity_history_b01_781201_generic/summary.json' >> "/home/wu/.agent-tasks/folr-entity-history-b01-781201-bank/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-bank/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-bank/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-entity-history-b01-781201-bank/status"
fi
echo "=== Task 'folr-entity-history-b01-781201-bank' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-entity-history-b01-781201-bank/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
