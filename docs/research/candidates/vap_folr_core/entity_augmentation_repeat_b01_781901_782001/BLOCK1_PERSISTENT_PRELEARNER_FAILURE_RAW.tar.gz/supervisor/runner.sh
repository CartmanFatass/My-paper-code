#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-augmentation-repeat-b01-781901-persistent/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-augmentation-repeat-b01-781901-persistent' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-augmentation-repeat-b01-781901-persistent/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/hmasd-worktrees/folr-entity-augmentation-repeat-b01-781901-782001/temp/directions/vap_folr_core/exp/entity_augmentation_repeat_b01_781901_782001/BLOCK1_PERSISTENT.sh 7975964542b83560cbc0e79f74a9212f8e3737af /home/wu/hmasd-worktrees/folr-entity-augmentation-repeat-b01-781901-782001 /home/wu/hmasd-worktrees/folr-entity-augmentation-repeat-b01-781901-782001/temp/directions/vap_folr_core/exp/entity_augmentation_repeat_b01_781901_782001/block1/persistent /home/wu/hmasd-worktrees/folr-entity-augmentation-repeat-b01-781901-782001/temp/directions/vap_folr_core/exp/entity_augmentation_repeat_b01_781901_782001/block1/generic/summary.json' >> "/home/wu/.agent-tasks/folr-augmentation-repeat-b01-781901-persistent/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-augmentation-repeat-b01-781901-persistent/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-augmentation-repeat-b01-781901-persistent/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-augmentation-repeat-b01-781901-persistent/status"
fi
echo "=== Task 'folr-augmentation-repeat-b01-781901-persistent' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-augmentation-repeat-b01-781901-persistent/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
