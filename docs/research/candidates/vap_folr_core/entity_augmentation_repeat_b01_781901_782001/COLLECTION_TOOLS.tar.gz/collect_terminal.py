"""Collect one terminal selected block/arm without native acquisition or restart."""
from pathlib import Path
import datetime, hashlib, json, math, subprocess, sys, tarfile
import torch

block, mode = int(sys.argv[1]), sys.argv[2]
if block not in (1, 2) or mode not in ('generic', 'persistent'):
    raise ValueError('only the four original selected endpoints are supported')
torch.set_num_threads(1)
seed = {1: 781901, 2: 782001}[block]
arm = 'GENERIC_RETAIN' if mode == 'generic' else 'AUGMENTED_PERSISTENT'
parameters, elements = (103173, 103199) if mode == 'generic' else (192741, 192768)
sha = '7975964542b83560cbc0e79f74a9212f8e3737af'
wt = Path('/home/wu/hmasd-worktrees/folr-entity-augmentation-repeat-b01-781901-782001')
base = wt/'temp/directions/vap_folr_core/exp/entity_augmentation_repeat_b01_781901_782001'
out, label = base/f'block{block}'/mode, f'BLOCK{block}_{mode.upper()}'
handle = f'folr-augmentation-repeat-b01-{seed}-{mode}'
status = json.loads(subprocess.check_output(['/usr/local/bin/agent-task', 'status', handle, '--json'], text=True))
if status.get('exit_code') is None:
    raise RuntimeError('terminal collection requires an actual terminal status')
record = {'collected_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'block': block,
          'mode': mode, 'handle': handle, 'source_sha': sha, 'status': status, 'cwd': str(wt), 'out': str(out), 'errors': []}
record['actual_head'] = subprocess.check_output(['git', '-C', str(wt), 'rev-parse', 'HEAD'], text=True).strip()
record['tracked_status'] = subprocess.check_output(['git', '-C', str(wt), 'status', '--porcelain', '--untracked-files=no'], text=True)
if record['actual_head'] != sha or record['tracked_status']:
    record['errors'].append('source checkout mismatch')
summary_path = out/'summary.json'
try:
    raw = summary_path.read_bytes()
    record.update(summary_sha256=hashlib.sha256(raw).hexdigest(), summary_bytes=len(raw))
    summary = json.loads(raw)
    required = {'object': 'FOLR_ENTITY_AUGMENTATION_REPEAT_B01_781901_782001', 'block': block,
                'arm': arm, 'status': 'complete', 'training_seed': seed, 'evaluation_seed': seed+1000000,
                'launch_sha': sha, 'training_episodes': 5000, 'training_ticks': 100000, 'optimizer_steps': 4969,
                'evaluation_episodes': 128, 'evaluation_ticks': 2560, 'actor_parameters': parameters, 'torch_threads': [1, 1]}
    record['binding'] = {k: summary.get(k) for k in (*required, 'actor_change_l2', 'torch_version', 'numpy_version')}
    record['errors'].extend(k+' mismatch' for k, v in required.items() if summary.get(k) != v)
    record['array_counts'] = {k: len(summary.get(k, [])) for k in ('training_returns', 'evaluation_returns')}
    for key, n in [('training_returns', 5000), ('evaluation_returns', 128)]:
        values = summary.get(key, [])
        if len(values) != n or not all(isinstance(v, (float, int)) and math.isfinite(v) for v in values):
            record['errors'].append(key+' invalid')
    record.update(native_panel=summary.get('native_panel'), pair_primary=summary.get('pair_primary'))
except (OSError, ValueError, TypeError, AttributeError) as exc:
    record['errors'].append('summary read: '+repr(exc))
generic = base/f'block{block}'/'generic/summary.json'
if mode == 'persistent' and generic.is_file():
    record['generic_input_sha256'] = hashlib.sha256(generic.read_bytes()).hexdigest()
checkpoint = out/'final.pt'
try:
    state = torch.load(checkpoint, weights_only=True)
    def tensors(x):
        if torch.is_tensor(x): yield x
        elif isinstance(x, dict):
            for v in x.values(): yield from tensors(v)
        elif isinstance(x, (list, tuple)):
            for v in x: yield from tensors(v)
    ts = list(tensors(state))
    ck = {'bytes': checkpoint.stat().st_size, 'sha256': hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
          'arm': state.get('arm'), 'updates': state.get('updates'), 'keys': list(state), 'tensor_count': len(ts),
          'all_finite': all(torch.isfinite(t).all().item() for t in ts), 'all_cpu': all(t.device.type == 'cpu' for t in ts),
          'floating_dtypes': sorted(set(str(t.dtype) for t in ts if t.is_floating_point())),
          'actor_state_elements': sum(t.numel() for t in state.get('actor', {}).values()),
          'target_actor_state_elements': sum(t.numel() for t in state.get('target_actor', {}).values()),
          'optimizer_slots': len(state.get('optimiser', {}).get('state', {}))}
    record['checkpoint'] = ck
    if not ck['all_finite'] or not ck['all_cpu'] or ck['updates'] != 4969 or ck['arm'] != arm or ck['actor_state_elements'] != elements or ck['target_actor_state_elements'] != elements or ck['floating_dtypes'] != ['torch.float32']:
        record['errors'].append('checkpoint conformance')
except Exception as exc:
    record['errors'].append('checkpoint read: '+repr(exc))
for filename, key in [('INVOCATION_TIME.json', 'invocation_time'), ('ADMISSION.json', 'admission')]:
    try: record[key] = json.loads((out/filename).read_bytes())
    except (OSError, ValueError) as exc: record[key] = None; record.setdefault('resources_unmeasured', []).append(key+': '+repr(exc))
if record['invocation_time'] and record['invocation_time']['exit_code'] != 0:
    record['errors'].append('invocation exit nonzero')
if status.get('exit_code') != 0: record['errors'].append('supervisor exit nonzero')
files = [(p, 'run/'+p.relative_to(out).as_posix()) for p in sorted(out.rglob('*')) if p.is_file()]
supervisor = Path('/home/wu/.agent-tasks')/handle
files.extend((p, 'supervisor/'+p.relative_to(supervisor).as_posix()) for p in sorted(supervisor.rglob('*')) if p.is_file())
record['manifest'] = [{'path': str(p), 'archive_name': rel, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p, rel in files]
archive = base/(label+'_RAW.tar.gz')
with tarfile.open(archive, 'w:gz') as tar:
    for p, rel in files: tar.add(p, arcname=rel, recursive=False)
record['archive'] = {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
with tarfile.open(archive, 'r:gz') as tar:
    record['archive_members_verified'] = all(hashlib.sha256(tar.extractfile(m['archive_name']).read()).hexdigest() == m['sha256'] for m in record['manifest'])
(base/(label+'_COLLECTION.json')).write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
