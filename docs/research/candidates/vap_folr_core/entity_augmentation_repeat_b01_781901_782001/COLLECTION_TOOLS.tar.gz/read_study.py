"""Read the four preserved endpoints once; no native acquisition or episode pooling."""
from pathlib import Path
import csv, datetime, hashlib, json, math, statistics, subprocess, sys

sys.path.insert(0, str(Path.cwd()))
from experiments.candidates.vap_folr_core.entity_augmentation_repeat_b01.publication import study_result

root = Path('docs/research/candidates/vap_folr_core/entity_augmentation_repeat_b01_781901_782001')
source = '7975964542b83560cbc0e79f74a9212f8e3737af'
for rel in ('experiments/candidates/vap_folr_core/entity_augmentation_repeat_b01/publication.py',
            'experiments/candidates/vap_folr_core/entity_persistence_b01/publication.py'):
    expected = subprocess.check_output(['git', 'show', source+':'+rel])
    actual = Path(rel).read_bytes().replace(b'\r\n', b'\n')
    assert actual == expected, ('publication source changed', rel)
summaries, collections, panels = [], [], {}
for block in (1, 2):
    own = []
    for mode in ('GENERIC', 'PERSISTENT'):
        label = f'BLOCK{block}_{mode}'
        raw = (root/(label+'_SUMMARY.json')).read_bytes()
        s, c = json.loads(raw), json.loads((root/(label+'_COLLECTION.json')).read_bytes())
        assert not c['errors'] and c['archive_members_verified']
        assert s['launch_sha'] == c['actual_head'] == source
        assert hashlib.sha256(raw).hexdigest() == c['summary_sha256']
        assert s['training_identity_kind'] == 'fresh_unscreened_fit' and s['actor_change_l2'] > 0
        assert s['final_checkpoint'] == c['out']+'/final.pt'
        values = s['evaluation_returns']
        panel = {'mean': statistics.mean(values), 'sample_sd': statistics.stdev(values),
                 'conditional_episode_se': statistics.stdev(values)/math.sqrt(len(values)),
                 'minimum': min(values), 'maximum': max(values), 'n': len(values),
                 'negative_count': sum(v < 0 for v in values)}
        assert all(math.isclose(v, s['native_panel'][k], rel_tol=1e-12, abs_tol=1e-12) for k, v in panel.items())
        assert math.isclose(panel['mean'], s['mean_native_return'], rel_tol=1e-12, abs_tol=1e-12)
        panels[label] = panel
        summaries.append(s); collections.append(c); own.append((s, c))
    assert own[1][1]['generic_input_sha256'] == own[0][1]['summary_sha256']
    assert own[1][0]['generic_input'] == own[0][1]['out']+'/summary.json'
primary = study_result(*summaries)
for index, block in enumerate((1, 2)):
    independent = panels[f'BLOCK{block}_PERSISTENT']['mean']-panels[f'BLOCK{block}_GENERIC']['mean']
    assert math.isclose(primary['ordered_differences'][index], independent, rel_tol=1e-12, abs_tol=1e-12)
    assert primary['blocks'][index] == summaries[2*index+1]['pair_primary']
d = primary['ordered_differences']
rule = ('BOTH_A_ABOVE_MEI' if all(v > 1 for v in d) else 'BOTH_G_ABOVE_MEI' if all(v < -1 for v in d)
        else 'BOTH_WITHIN_MEI' if all(-1 <= v <= 1 for v in d) else 'MIXED_BLOCK_PATTERN')
assert primary['rule'] == rule and primary['descriptive_mean_difference'] == statistics.mean(d)
counts = {k: sum(s[k] for s in summaries) for k in ('training_episodes', 'training_ticks', 'optimizer_steps', 'evaluation_episodes', 'evaluation_ticks')}
measured = [c['invocation_time'] for c in collections if c['invocation_time']]
cost = {'invocations_with_external_timing': len(measured), 'native_wall_measured_sum_seconds': sum(c['wall_seconds'] for c in measured),
        'aggregate_cpu_measured_sum_seconds': sum(c['user_seconds']+c['system_seconds'] for c in measured),
        'peak_rss_kib_measured_max': max((c['peak_rss_kib'] for c in measured), default=None),
        'support_provider_lifetime_total': 'UNKNOWN'}
record = {'readback_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_sha': source,
          'primary_recomputed': primary, 'independent_ordered_rule': rule, 'recomputed_panels': panels,
          'complete_counts': counts, 'new_training_instances': 4, 'fresh_contrast_blocks': 2,
          'exposure_line': '4 fresh fits; 400000 train ticks; 19876 RMSprop steps; 4 final checkpoints; 512 final greedy episodes/10240 eval ticks; 0 screening/retry/checkpoint selection',
          'cost': cost, 'training_population_uncertainty': 'not estimated; two complete block realizations, evaluation variation included',
          'within_block_common_labels': 'intentional construction alignment, not evidence of paired worlds or independent arm draws'}
(root/'STUDY_READBACK.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n', encoding='utf-8')
with (root/'RUN_SCORES.csv').open('w', encoding='utf-8', newline='') as f:
    writer = csv.writer(f); writer.writerow(['task', 'seed', 'arm', 'score'])
    for s in summaries: writer.writerow([s['object'], s['training_seed'], s['arm'], s['mean_native_return']])
print(json.dumps(record, allow_nan=False))
