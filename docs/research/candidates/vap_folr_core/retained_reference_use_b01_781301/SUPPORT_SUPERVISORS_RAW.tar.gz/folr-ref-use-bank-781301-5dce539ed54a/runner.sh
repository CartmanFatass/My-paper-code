#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/folr-ref-use-bank-781301-5dce539ed54a/pid"
START_TS=$(date +%s)
echo "=== Task 'folr-ref-use-bank-781301-5dce539ed54a' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/folr-ref-use-bank-781301-5dce539ed54a/task.log"

# Execute command capturing output
set +e
eval 'bash /home/wu/projects/HMASD/temp/directions/vap_folr_core/exp/retained_reference_use_b01_781301/prepared/BANK.sh 5dce539ed54afd4334d09db9dcd94df38c52c2fc /home/wu/hmasd-worktrees/folr-ref-use-5dce539ed54a /home/wu/projects/HMASD/temp/directions/vap_folr_core/exp/retained_reference_use_b01_781301/BANK /home/wu/projects/HMASD/temp/directions/vap_folr_core/exp/retained_reference_use_b01_781301/GENERIC/summary.json /home/wu/hmasd-inputs/vap_folr_core/retained_reference_use_b01_781301/BANK_final.pt' >> "/home/wu/.agent-tasks/folr-ref-use-bank-781301-5dce539ed54a/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/folr-ref-use-bank-781301-5dce539ed54a/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/folr-ref-use-bank-781301-5dce539ed54a/status"
else
    echo "failed" > "/home/wu/.agent-tasks/folr-ref-use-bank-781301-5dce539ed54a/status"
fi
echo "=== Task 'folr-ref-use-bank-781301-5dce539ed54a' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/folr-ref-use-bank-781301-5dce539ed54a/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
