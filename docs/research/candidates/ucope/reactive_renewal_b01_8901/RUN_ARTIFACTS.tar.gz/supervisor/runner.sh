#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/ucope-reactive-renewal-b01-8901/pid"
START_TS=$(date +%s)
echo "=== Task 'ucope-reactive-renewal-b01-8901' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/ucope-reactive-renewal-b01-8901/task.log"

# Execute command capturing output
set +e
eval 'bash -lc '\''cd /home/wu/hmasd-worktrees/ucope-reactive-renewal-b01-8901-831b83c15 && /home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out temp/directions/ucope/exp/ucope-reactive-renewal-b01-8901/memory.json && /usr/bin/time -v -o temp/directions/ucope/exp/ucope-reactive-renewal-b01-8901/time.txt /home/wu/.venvs/hmasd/bin/python scripts/run_ucope_reactive_renewal_b01.py --seed 8901 --out temp/directions/ucope/exp/ucope-reactive-renewal-b01-8901 --watchdog-seconds 6000'\''' >> "/home/wu/.agent-tasks/ucope-reactive-renewal-b01-8901/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/ucope-reactive-renewal-b01-8901/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/ucope-reactive-renewal-b01-8901/status"
else
    echo "failed" > "/home/wu/.agent-tasks/ucope-reactive-renewal-b01-8901/status"
fi
echo "=== Task 'ucope-reactive-renewal-b01-8901' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/ucope-reactive-renewal-b01-8901/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
