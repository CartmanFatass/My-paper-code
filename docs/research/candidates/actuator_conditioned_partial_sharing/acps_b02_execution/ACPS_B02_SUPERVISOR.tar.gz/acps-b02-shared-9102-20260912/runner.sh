#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/acps-b02-shared-9102-20260912/pid"
START_TS=$(date +%s)
echo "=== Task 'acps-b02-shared-9102-20260912' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/acps-b02-shared-9102-20260912/task.log"

# Execute command capturing output
set +e
eval '/usr/bin/time -q -f %e -o /home/wu/hmasd-worktrees/acps-b02-9102-20260912/temp/directions/actuator_conditioned_partial_sharing/exp/acps_b02_9102/SHARED/process_wall_seconds.txt bash /home/wu/hmasd-inputs/acps-b02-9102-20260912/run_shared.sh' >> "/home/wu/.agent-tasks/acps-b02-shared-9102-20260912/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/acps-b02-shared-9102-20260912/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/acps-b02-shared-9102-20260912/status"
else
    echo "failed" > "/home/wu/.agent-tasks/acps-b02-shared-9102-20260912/status"
fi
echo "=== Task 'acps-b02-shared-9102-20260912' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/acps-b02-shared-9102-20260912/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
