#!/usr/bin/env bash
echo $$ > "/home/wu/.agent-tasks/vsp03-b07-10804-20260910/pid"
START_TS=$(date +%s)
echo "=== Task 'vsp03-b07-10804-20260910' started at $(date -Iseconds) ===" >> "/home/wu/.agent-tasks/vsp03-b07-10804-20260910/task.log"

# Execute command capturing output
set +e
eval '/home/wu/.venvs/hmasd/bin/python /home/wu/hmasd-worktrees/vsp03-b07-adcff0a92559ac5552e24a9861e2b65572b478c5/experiments/candidates/vsp_03/vsp03_b04/deadline.py --start-monotonic 517780.880234 --cap 60.0 --reserve 10.0 --record /home/wu/projects/HMASD/temp/directions/vsp_03/exp/b07_10804_20260910_terminal.payload.json -- bash -c '\''/home/wu/.venvs/hmasd/bin/python scripts/hmasd_resource_preflight.py admit-memory --out "$1" && /home/wu/.venvs/hmasd/bin/python scripts/run_vsp03_b06.py --seed "$2" --out "$3" --node wsl_4070 --started-monotonic "$VSP03_B04_STARTED"'\'' bash /home/wu/projects/HMASD/temp/directions/vsp_03/exp/b07_10804_20260910_admission.json 10804 /home/wu/projects/HMASD/temp/directions/vsp_03/exp/b07_10804_20260910' >> "/home/wu/.agent-tasks/vsp03-b07-10804-20260910/task.log" 2>&1
EXIT_CODE=$?
set -e

END_TS=$(date +%s)
echo $EXIT_CODE > "/home/wu/.agent-tasks/vsp03-b07-10804-20260910/exit_code"
if [ $EXIT_CODE -eq 0 ]; then
    echo "finished" > "/home/wu/.agent-tasks/vsp03-b07-10804-20260910/status"
else
    echo "failed" > "/home/wu/.agent-tasks/vsp03-b07-10804-20260910/status"
fi
echo "=== Task 'vsp03-b07-10804-20260910' exited with code $EXIT_CODE at $(date -Iseconds) (Duration: $((END_TS - START_TS))s) ===" >> "/home/wu/.agent-tasks/vsp03-b07-10804-20260910/task.log"

# Keep session alive briefly for inspection, then exit
sleep 1
