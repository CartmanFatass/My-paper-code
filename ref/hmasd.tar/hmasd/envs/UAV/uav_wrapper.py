
import numpy as np
import gymnasium as gym
from gymnasium.spaces import Box, Discrete

class UAVHMASDWrapper:
    """
    Wrapper to adapt UAVForcedRelayEnv to the HMASD (StarCraft2Env-like) interface.
    """
    def __init__(self, env):
        self.env = env
        self.n_agents = self.env.n_uavs
        # Map requires n_enemies for some logic, but for UAV we might not have enemies.
        # We set it to 0 or some dummy value if needed.
        self.n_enemies = 0 
        self.episode_limit = self.env.max_steps
        
        # Spaces
        self.observation_space = []
        self.share_observation_space = []
        self.action_space = []

        # Get dimensions from env
        # Assuming homogeneous agents for now based on UAV.py
        obs_dim = self.env.get_obs_dim()
        # Force state_dim to match concatenated obs
        state_dim = obs_dim * self.n_agents
        print(f"Wrapper initialized: obs_dim={obs_dim}, state_dim={state_dim}")
        if state_dim is None or state_dim == 0:
            state_dim = obs_dim * self.n_agents

        for i in range(self.n_agents):
            self.observation_space.append([obs_dim])
            self.share_observation_space.append([state_dim])
            
            # Action space
            # UAV.py has action_spaces dict.
            # We assume continuous or discrete based on env config.
            # Assuming discrete for now matching typical HMASD usage, but UAV might be continuous?
            # UAV.py has self.action_space_type
            if hasattr(self.env, 'action_space_type') and self.env.action_space_type == 'continuous':
                 # HMASD typically supports discrete. If continuous, we might need specific runner support.
                 # But let's check config. The runner uses PPO which can handle continuous.
                 # We just expose the space.
                 # self.env.action_spaces is a dict.
                 # We need to check the space for agent 0.
                 agent_id = self.env.agents[0]
                 self.action_space.append(self.env.action_spaces[agent_id])
            else:
                 # Discrete
                 agent_id = self.env.agents[0]
                 self.action_space.append(self.env.action_spaces[agent_id])

    def reset(self):
        """
        Returns:
            local_obs: [n_agents, obs_dim]
            global_state: [n_agents, state_dim]
            available_actions: [n_agents, n_actions] (if discrete) or None
        """
        try:
             obs_dict, info = self.env.reset()
        except Exception as e:
             import traceback
             traceback.print_exc()
             raise e
        
        # Parse obs_dict to separate obs and potentially action_masks
        local_obs, action_masks = self._parse_obs(obs_dict)
        self.last_action_masks = action_masks
        
        global_state = self._get_global_state(local_obs)
        available_actions = self._get_available_actions()
        
        return local_obs, global_state, available_actions

    def step(self, actions):
        """
        Args:
            actions: list or array of actions [n_agents, action_dim] or [n_agents]
        Returns:
            local_obs, global_state, rewards, dones, infos, available_actions
        """
        # Convert actions to dict expected by PettingZoo
        # HMASD passes actions as array
        actions_dict = {}
        for i, agent_id in enumerate(self.env.agents):
            if i < len(actions):
                if hasattr(self.env, 'action_space_type') and self.env.action_space_type == 'discrete':
                     # If generic discrete, it might be an integer or one-hot.
                     # PettingZoo expects integer for Discrete space.
                     # HMASD might output one-hot or integer depending on algo.
                     # Usually runner sends integers (actions_int).
                     try:
                        actions_dict[agent_id] = int(actions[i])
                     except:
                        actions_dict[agent_id] = actions[i] # handling array/tensor
                else:
                     actions_dict[agent_id] = actions[i]

        try:
             obs_dict, rewards, terminations, truncations, infos = self.env.step(actions_dict)
        except Exception as e:
             import traceback
             traceback.print_exc()
             raise e
        
        local_obs, action_masks = self._parse_obs(obs_dict)
        self.last_action_masks = action_masks
        
        global_state = self._get_global_state(local_obs)
        
        rewards_arr = np.array([rewards[agent] for agent in self.env.agents]).reshape(self.n_agents, 1)
        
        # Dones: HMASD expects 'dones' to be boolean array.
        # Combine termination and truncation
        dones_arr = np.array([terminations[agent] or truncations[agent] for agent in self.env.agents])
        
        # Infos
        infos_arr = [infos[agent] for agent in self.env.agents]
        
        available_actions = self._get_available_actions()
        
        return local_obs, global_state, rewards_arr, dones_arr, infos_arr, available_actions

    def seed(self, seed=None):
        if hasattr(self.env, 'seed'):
             self.env.seed(seed)
        
    def close(self):
        self.env.close()

    def _parse_obs(self, obs_dict):
        """
        Parse dict of observations to array [n_agents, obs_dim]
        and extract action masks if available.
        """
        obs_list = []
        action_masks_list = []
        
        for agent in self.env.agents:
            agent_obs = obs_dict[agent]
            
            # Check if observation is a dictionary (PettingZoo Dict space)
            if isinstance(agent_obs, dict) and "obs" in agent_obs:
                obs_list.append(agent_obs["obs"])
                if "action_mask" in agent_obs:
                    action_masks_list.append(agent_obs["action_mask"])
                else:
                    action_masks_list.append(None)
            else:
                # Standard array observation
                obs_list.append(agent_obs)
                action_masks_list.append(None)
                
        return np.array(obs_list), action_masks_list

    def _dict_to_array(self, obs_dict):
        # Deprecated/wrapped by _parse_obs, but kept for compatibility if needed internally
        obs, _ = self._parse_obs(obs_dict)
        return obs

    def _get_global_state(self, local_obs):
        """
        Construct global state.
        If environment uses centralized V, it needs global state.
        We concat local obs as a default global state.
        """
        # If env has detailed state method, use it.
        # TODO: Check if UAVForcedRelayEnv has a hidden state accessor.
        # For now, concat.
        
        # Flatten local_obs [n_agents, obs_dim] -> [n_agents * obs_dim]
        files_obs = local_obs.flatten()
        # Broadcast to [n_agents, state_dim]
        # HMASD expects specific shape.
        
        # However, checking StarCraft2Env:
        # global_state = [self.get_state_without_as() for agent_id in range(self.n_agents)]
        # get_state_without_as returns a vector.
        # So global_state is list of vectors.
        
        # If we use concat, state_dim = n_agents * obs_dim
        # create array [n_agents, state_dim] where each row is the concatenated state.
        state = np.tile(files_obs, (self.n_agents, 1))
        return state

    def _get_available_actions(self):
        """
        Return available actions for each agent.
        For UAV, usually all actions are available unless discrete and masking is needed.
        """
        if hasattr(self.env, 'action_space_type') and self.env.action_space_type == 'discrete':
             dim = self.action_space[0].n
             
             # If we have valid masks from the last observation, use them
             if hasattr(self, 'last_action_masks') and self.last_action_masks and len(self.last_action_masks) == self.n_agents:
                 # Check if the first mask is valid and has correct shape
                 first_mask = self.last_action_masks[0]
                 if first_mask is not None and len(first_mask) == dim:
                     return np.array(self.last_action_masks, dtype=np.float32)
             
             # Fallback to all ones
             return np.ones((self.n_agents, dim), dtype=np.float32)
        else:
             return None

