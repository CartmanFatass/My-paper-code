#!/usr/bin/env python
import sys
import os
import wandb
import socket
import setproctitle
import numpy as np
from pathlib import Path
import torch
import random
# Path: train_uav.py -> train -> scripts -> hmasd -> NeurIPS2023_HMASD_code
sys.path.append(str(Path(__file__).resolve().parents[3]))
from hmasd.config import get_config
from hmasd.envs.UAV.UAV import UAVForcedRelayEnv
from hmasd.envs.UAV.uav_wrapper import UAVHMASDWrapper
from hmasd.envs.env_wrappers import ShareSubprocVecEnv, ShareDummyVecEnv
from hmasd.runner.shared.uav_runner import UAVRunner as Runner

"""Train script for UAV."""

def make_train_env(all_args):
    def get_env_fn(rank):
        def init_env():
            if all_args.env_name == "UAV":
                env = UAVForcedRelayEnv(all_args)
                env = UAVHMASDWrapper(env)
            else:
                print("Can not support the " + all_args.env_name + "environment.")
                raise NotImplementedError
            env.seed(all_args.seed + rank * 1000)
            return env

        return init_env

    if all_args.n_rollout_threads == 1:
        return ShareDummyVecEnv([get_env_fn(0)])
    else:
        return ShareSubprocVecEnv([get_env_fn(i) for i in range(all_args.n_rollout_threads)])


def make_eval_env(all_args):
    def get_env_fn(rank):
        def init_env():
            if all_args.env_name == "UAV":
                env = UAVForcedRelayEnv(all_args)
                env = UAVHMASDWrapper(env)
            else:
                print("Can not support the " + all_args.env_name + "environment.")
                raise NotImplementedError
            env.seed(all_args.seed * 50000 + rank * 10000)
            return env

        return init_env

    if all_args.n_eval_rollout_threads == 1:
        return ShareDummyVecEnv([get_env_fn(0)])
    else:
        return ShareSubprocVecEnv([get_env_fn(i) for i in range(all_args.n_eval_rollout_threads)])


def parse_args(args, parser):
    parser.add_argument('--map_name', type=str, default='uav_forced_relay', help="Which map to run on")
    
    # UAV Environment specific configurations
    parser.add_argument("--n_agents", type=int, default=12, help="Number of UAVs")
    parser.add_argument("--n_users", type=int, default=80, help="Number of users")
    parser.add_argument("--area_size", type=int, default=2500, help="Area size")
    parser.add_argument("--max_steps", type=int, default=None, help="Max steps per episode for UAV env. If None, uses episode_length.")
    
    # Reward and distribution settings
    parser.add_argument("--reward_type", type=str, default="naive", 
                        choices=["naive", "load_balance", "test_reward", "handover", "awareness"],
                        help="Reward type for UAV environment")
    parser.add_argument("--user_distribution", type=str, default="forced_relay_cluster",
                        help="User distribution type")
    parser.add_argument("--n_clusters", type=int, default=4, help="Number of user clusters")
    parser.add_argument("--n_ground_bs", type=int, default=1, help="Number of ground base stations")
    
    # Reward weights
    parser.add_argument("--w_load_balance", type=float, default=0.5, help="Load balance weight")
    parser.add_argument("--w_first_contact", type=float, default=0.1, help="First contact weight")
    parser.add_argument("--w_repulsion", type=float, default=0.3, help="Repulsion weight")
    
    all_args = parser.parse_known_args(args)[0]
    
    # Sync max_steps with episode_length if not specified
    if all_args.max_steps is None:
        all_args.max_steps = all_args.episode_length

    return all_args


def main(args):
    parser = get_config()
    all_args = parse_args(args, parser)

    # cuda
    if all_args.cuda and torch.cuda.is_available():
        print("choose to use gpu...")
        device = torch.device("cuda:0")
        torch.set_num_threads(all_args.n_training_threads)
        if all_args.cuda_deterministic:
            torch.backends.cudnn.benchmark = False
            torch.backends.cudnn.deterministic = True
    else:
        print("choose to use cpu...")
        device = torch.device("cpu")
        torch.set_num_threads(all_args.n_training_threads)

    run_dir = Path(os.path.split(os.path.dirname(os.path.abspath(__file__)))[
                       0] + "/results") / all_args.env_name / all_args.map_name / all_args.algorithm_name / all_args.experiment_name
    if not run_dir.exists():
        os.makedirs(str(run_dir))

    if all_args.use_wandb:
        # Use None for entity if user_name is default 'marl'
        wandb_entity = None if all_args.user_name == 'marl' else all_args.user_name
        run = wandb.init(config=all_args,
                         project=all_args.env_name,
                         entity=wandb_entity,
                         notes=socket.gethostname(),
                         name=str(all_args.algorithm_name) + "_" +
                              str(all_args.experiment_name) +
                              "_seed" + str(all_args.seed),
                         group=all_args.map_name,
                         dir=str(run_dir),
                         job_type="training",
                         reinit=True)
    else:
        if not run_dir.exists():
            curr_run = 'run1'
        else:
            exst_run_nums = [int(str(folder.name).split('run')[1]) for folder in run_dir.iterdir() if
                             str(folder.name).startswith('run')]
            if len(exst_run_nums) == 0:
                curr_run = 'run1'
            else:
                curr_run = 'run%i' % (max(exst_run_nums) + 1)
        run_dir = run_dir / curr_run
        if not run_dir.exists():
            os.makedirs(str(run_dir))

    setproctitle.setproctitle(
        str(all_args.algorithm_name) + "-" + str(all_args.env_name) + "-" + str(all_args.experiment_name) + "@" + str(
            all_args.user_name))

    # seed
    random.seed(all_args.seed)
    os.environ['PYTHONHASHSEED'] = str(all_args.seed)
    np.random.seed(all_args.seed)
    torch.manual_seed(all_args.seed)
    torch.cuda.manual_seed(all_args.seed)
    torch.cuda.manual_seed_all(all_args.seed)

    # env
    num_agents = all_args.n_agents
    all_args.run_dir = run_dir
    envs = make_train_env(all_args)
    eval_envs = make_eval_env(all_args) if all_args.use_eval else None

    config = {
        "all_args": all_args,
        "envs": envs,
        "eval_envs": eval_envs,
        "num_agents": num_agents,
        "device": device,
        "run_dir": run_dir
    }

    runner = Runner(config)
    runner.run()

    # post process
    envs.close()
    if all_args.use_eval and eval_envs is not envs:
        eval_envs.close()

    if all_args.use_wandb:
        run.finish()
    else:
        runner.writter.export_scalars_to_json(str(runner.log_dir + '/summary.json'))
        runner.writter.close()


if __name__ == "__main__":
    main(sys.argv[1:])
