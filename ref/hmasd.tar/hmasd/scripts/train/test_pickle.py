"""Test UAV environment serialization with cloudpickle"""
import sys
import os

# Add the hmasd directory to path
hmasd_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, hmasd_dir)

import cloudpickle

print("Testing UAV environment serialization...")
print(f"HMASD dir: {hmasd_dir}")

# Create minimal args
class MinimalArgs:
    n_agents = 5
    n_users = 30
    area_size = 2500
    max_steps = 100
    reward_type = 'naive'
    episode_length = 100

args = MinimalArgs()

try:
    from hmasd.envs.UAV.UAV import UAVForcedRelayEnv
    print("1. UAVForcedRelayEnv imported OK")
    
    from hmasd.envs.UAV.uav_wrapper import UAVHMASDWrapper
    print("2. UAVHMASDWrapper imported OK")
    
    env = UAVForcedRelayEnv(args)
    print("3. UAVForcedRelayEnv created OK")
    
    wrapped = UAVHMASDWrapper(env)
    print("4. UAVHMASDWrapper created OK")
    
    # Test serialization
    serialized = cloudpickle.dumps(wrapped)
    print(f"5. Serialization OK! Size: {len(serialized)} bytes")
    
    # Test deserialization
    restored = cloudpickle.loads(serialized)
    print("6. Deserialization OK!")
    
    print("\n=== All tests passed! Environment can be pickled. ===")
    
except Exception as e:
    import traceback
    print(f"\nERROR: {e}")
    traceback.print_exc()
