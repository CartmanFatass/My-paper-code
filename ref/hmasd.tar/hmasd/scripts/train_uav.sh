#!/bin/bash
# HMASD UAV 训练脚本 - 基于 config_1.py 优化配置
# 用法: bash scripts/train_uav.sh

# 设置代理 (如需要)
# export HTTP_PROXY="http://127.0.0.1:7890"
# export HTTPS_PROXY="http://127.0.0.1:7890"

# 环境参数 (来自 config_1.py)
ENV_NAME="UAV"
N_AGENTS=5
N_USERS=30
AREA_SIZE=8000
EPISODE_LENGTH=500
MAX_STEPS=500

# UAV环境特定参数 (来自 config_1.py)
REWARD_TYPE="test_reward"           # 奖励类型: naive, load_balance, test_reward, handover, awareness
USER_DISTRIBUTION="forced_relay_cluster"
N_CLUSTERS=5
N_GROUND_BS=1
W_LOAD_BALANCE=0.5
W_FIRST_CONTACT=0
W_REPULSION=0

# 训练参数
NUM_ENV_STEPS=3200000        # num_envs * rollout_length * 400 = 32 * 500 * 400
N_ROLLOUT_THREADS=4         # num_envs
EXPERIMENT_NAME="uav_config1_$(date +%Y%m%d_%H%M%S)"

N_TRAINING_THREADS=1        # torch threads

# HMASD 参数

SKILL_INTERVAL=10            # k=10
TEAM_SKILL_DIM=6             # n_Z (团队技能维度)
INDI_SKILL_DIM=6             # n_z (个体技能维度)
HIDDEN_SIZE=256

# PPO 参数 (高层策略 h_ 和低层策略 l_)
H_GAMMA=0.99
H_GAE_LAMBDA=0.95
H_CLIP_PARAM=0.2
H_PPO_EPOCH=15
H_VALUE_LOSS_COEF=1.0
H_MAX_GRAD_NORM=0.5
H_NUM_MINI_BATCH=4

L_GAMMA=0.99
L_GAE_LAMBDA=0.95
L_CLIP_PARAM=0.2
L_PPO_EPOCH=15
L_VALUE_LOSS_COEF=1.0
L_MAX_GRAD_NORM=0.5
L_NUM_MINI_BATCH=4

# 熵系数参数
H_ENTROPY_COEF_START=0.07
H_ENTROPY_COEF_END=0.01
H_ENTROPY_COEF_DECAY=1       # config.py 期望 int 类型, 1=True
L_ENTROPY_COEF=0.05

# 内在奖励权重
LAMBDA_ENV=1.0
LAMBDA_TEAM=0.05
LAMBDA_INDI=0.02

# 评估参数
EVAL_INTERVAL=10
EVAL_EPISODES=4

# WandB 设置 (可选)
USE_WANDB=""                  # 置空使用 TensorBoard, 设为 "--use_wandb" 则使用 WandB
WANDB_USER="czqtpkqc"        # 替换为你的 wandb 用户名

# 运行训练
python scripts/train/train_uav.py \
    --env_name ${ENV_NAME} \
    --algorithm_name hmasd \
    --experiment_name ${EXPERIMENT_NAME} \
    --n_agents ${N_AGENTS} \
    --n_users ${N_USERS} \
    --area_size ${AREA_SIZE} \
    --episode_length ${EPISODE_LENGTH} \
    --max_steps ${MAX_STEPS} \
    --reward_type ${REWARD_TYPE} \
    --user_distribution ${USER_DISTRIBUTION} \
    --n_clusters ${N_CLUSTERS} \
    --n_ground_bs ${N_GROUND_BS} \
    --w_load_balance ${W_LOAD_BALANCE} \
    --w_first_contact ${W_FIRST_CONTACT} \
    --w_repulsion ${W_REPULSION} \
    --num_env_steps ${NUM_ENV_STEPS} \
    --n_rollout_threads ${N_ROLLOUT_THREADS} \
    --n_training_threads ${N_TRAINING_THREADS} \
    --skill_interval ${SKILL_INTERVAL} \
    --team_skill_dim ${TEAM_SKILL_DIM} \
    --indi_skill_dim ${INDI_SKILL_DIM} \
    --hidden_size ${HIDDEN_SIZE} \
    --h_gamma ${H_GAMMA} \
    --h_gae_lambda ${H_GAE_LAMBDA} \
    --h_clip_param ${H_CLIP_PARAM} \
    --h_ppo_epoch ${H_PPO_EPOCH} \
    --h_value_loss_coef ${H_VALUE_LOSS_COEF} \
    --h_max_grad_norm ${H_MAX_GRAD_NORM} \
    --h_num_mini_batch ${H_NUM_MINI_BATCH} \
    --l_gamma ${L_GAMMA} \
    --l_gae_lambda ${L_GAE_LAMBDA} \
    --l_clip_param ${L_CLIP_PARAM} \
    --l_ppo_epoch ${L_PPO_EPOCH} \
    --l_value_loss_coef ${L_VALUE_LOSS_COEF} \
    --l_max_grad_norm ${L_MAX_GRAD_NORM} \
    --l_num_mini_batch ${L_NUM_MINI_BATCH} \
    --h_entropy_coef_start ${H_ENTROPY_COEF_START} \
    --h_entropy_coef_end ${H_ENTROPY_COEF_END} \
    --h_entropy_coef_decay ${H_ENTROPY_COEF_DECAY} \
    --l_entropy_coef ${L_ENTROPY_COEF} \
    --lambda_env ${LAMBDA_ENV} \
    --lambda_team ${LAMBDA_TEAM} \
    --lambda_indi ${LAMBDA_INDI} \
    --eval_interval ${EVAL_INTERVAL} \
    --eval_episodes ${EVAL_EPISODES} \
    --use_valuenorm \
    --use_ReLU \
    ${USE_WANDB} \
    --user_name ${WANDB_USER}

echo "Training completed!"
